% Load data from csv file

pkg load io
dataFromFile=dlmread('trainclean.csv');
%Remove header
dataFromFile=dataFromFile(2:end,:);
%-- Check First Row of data. 
dataFromFile(1,:)
%-- Store values of output in Y.
outputlabel = dataFromFile(:,end);
dataFromFile=dataFromFile(:,1:end-1);
#-- Remove IS_ALONE column from the dataset.
dataFromFile(:,[9])=[];

%-- Add New Feature Total Fare familysize * Fare
dataFromFile = [dataFromFile dataFromFile(:,6).*dataFromFile(:,8)];
%-- Add Polynomial feature for Family Size and Age.
dataFromFile = [dataFromFile  dataFromFile(:,8).^2];

%-- Scaling Feature Age and Fare between 0 to 1
##[ScaledFeature]=featureScaling([dataFromFile(:,3) , dataFromFile(:,6)]);
##dataFromFile(:,3)=ScaledFeature(:,1);
##dataFromFile(:,6)=ScaledFeature(:,2);

%-- Add Second level polinomical for Age, FamilySize,TotalFare.
%-- That is calculated above.
%-- FamilySize
##FamilySize_2_order=dataFromFile(:,8).^2;
%-- Age
##Age_2_order=dataFromFile(:,3).^2;
%-- Total Fare
%-- Total_Fare_2_order=dataFromFile(:,13).^2;

%-- Add Parameter to File Frame
##dataFromFile=[dataFromFile FamilySize_2_order];
##dataFromFile (1,:)

##dataFromFile=[dataFromFile Age_2_order];
##dataFromFile=[dataFromFile Total_Fare_2_order];
m=size(dataFromFile,1);
% Build Training, Validation and test data set. 

sampleseq=randperm(m);
mtrain=ceil(m*0.60);
mval=floor(m*0.20);
mtest=floor(m*0.20);

trainIndex=sampleseq(1:mtrain);
valIndex=sampleseq(mtrain+1:mtrain+mval);
testIndex=sampleseq(mtrain+mval+1:mtrain+mval+mtest);
##size(trainIndex)
##mtrain
##size(valIndex)
##mval
##size(testIndex)
##mtest


% Build input and output
[m n]=size(dataFromFile);
X = dataFromFile(trainIndex(:),:);
y = outputlabel(trainIndex(:));

##X(1,:)
Xval = dataFromFile(valIndex(:),:);
yval= outputlabel(valIndex(:));

Xtest=dataFromFile (testIndex(:),:);
ytest=outputlabel(testIndex(:));


% Add second degree Polynomial Feature in Train set.
##xsecondorder=addPolynomial(X,2);
##xthirdorder=addPolynomial(X,3);
##X=[X xsecondorder xthirdorder];

initial_theta=zeros(size(X,2)+1,1);

lambda=0;
[J grad]=costFunction(X,y,initial_theta,lambda);
fprintf("\n Error cost for initial_theta is: %d\n",J);

% Optimize gredient using fmincg function
option=optimset('GradObj','on','MaxIter',500);
[theta J]=fminunc(@(t)costFunction(X,y,t,lambda),initial_theta,option);
fprintf("\n Error Cost After optimization is: %d\n",J);

%------------------------------------------ Learning Curve ------------------------------------------
%--- Based on the Leaning Curve. Feature seems good. 
%--- So, we will use the same features.
##[error_train,error_val]  = learningCurve(X,y,Xval,yval,lambda);
##plot(1:size(error_train,1),error_train,1:size(error_train,1),error_val);
##axis([0 1000 0 5])
%------------------------------------------ Calculate prediction efficiency ------------------------------------------

pTrain=predict(X,theta);
effTrain=mean(pTrain==y);
[p,r,f1train] = f1score(pTrain,y);
f1train 

pVal=predict(Xval,theta);
effVal=mean(pVal==yval);
[p,r,f1val] = f1score(pVal,yval);

pTest=predict(Xtest,theta);
effTest=mean(pTest==ytest);
[p,r,f1test]= f1score(pTest,ytest);


fprintf("\n Training Data Set efficiency: %d\n Validation Data Set efficiency: %d\n Test Data Set efficiency: %d\n",effTrain,effVal,effTest);
fprintf("\n F1-Score for Training Dataset is: %d\n F1-Score for Validation Dataset is: %d\n F1-Score for Testing Dataset is: %d\n",f1train,f1val,f1test);

%------------------------------------------ Predict based on test dataset ------------------------------------------

testdata = dlmread('testclean.csv');
%--- Build input and output variable
XTest=testdata(2:end,:);
XTest(:,[9])=[];
XTest = [XTest XTest(:,6).*XTest(:,8)];
%-- Add Polynomial feature for Family Size and Age.
XTest = [XTest  XTest(:,8).^2];


##ScaledFeature=featureScaling([XTest(:,3) , XTest(:,6)]);
##XTest(:,3)=ScaledFeature(:,1);
##XTest(:,6)=ScaledFeature(:,2);
pTest=predict(XTest,theta);
size(pTest)
save "prediction.txt" pTest
