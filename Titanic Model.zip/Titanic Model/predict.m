function [prediction]= predict(X,theta)
  X=[ones(size(X,1),1) X];
  prediction=X*theta;
  prediction=sigmoid(prediction);
  prediction=prediction>=0.5;
endfunction
