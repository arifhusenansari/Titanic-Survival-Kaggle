function [error_train,error_val] = learningCurve(X,y,Xval,yval,lambda)
  % for learned parameter. Check Learning Rate for different size of training set. 
  
  initial_theta=zeros(size(X,2)+1,1);
  m=size(X,1);
  error_train =zeros(m,1);
  error_val=zeros(m,1);
  
  for i=1:m
    Xtrain=X(1:i,:);
    ytrain=y(1:i);
    option=optimset('GradObj','on','MaxIter',100);
    [theta]=fminunc(@(t) costFunction(Xtrain,ytrain,t,lambda),initial_theta,option);
    jTrain=costFunction(Xtrain,ytrain,theta,lambda);
    jval=costFunction(Xval,yval,theta,lambda);
    error_train(i)=jTrain;
    if ( jval==Inf)
      error_val(i)=error_val(i-1);
    else
      error_val(i)=jval;
    endif     
    
  endfor
endfunction
