function X = addPolynomial(X,degree)
  xploy=X.^degree;
  X=[X xploy];
endfunction
