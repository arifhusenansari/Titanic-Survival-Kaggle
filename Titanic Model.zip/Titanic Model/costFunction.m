function [J,grad]= costFunction(X,y,theta,lambda)
  
  
  % Cost Calculation using Regularization
  % Add biased feture in X
  X=[ones(size(X,1),1) X];
  [m n]=size(X);
  prediction = X*theta;
  finalPrediction=sigmoid(prediction);
##  % Cost without regularization.
##  J= sum(-((y.*log(finalPrediction)+(1-y).*log(1-finalPrediction))./m));
##  % Gradient without regularization
##  grad= sum((X.*(finalPrediction-y))./m)';
  % Cost.
  % Regularization. Skip first Parameter. 
  
  reg=((lambda/(2*m)).*(theta(2:end)'*theta(2:end)));
  J= sum(-((y.*log(finalPrediction)+(1-y).*log(1-finalPrediction))./m));
  J=J+reg;
  % Gradient
  grad=(X.*(finalPrediction-y))./m;
  grad=[grad ; zeros(1,size(grad,2))];
  grad= sum(grad);
  grad=grad';
  grad(2:end)=  grad(2:end)+(lambda/m).*theta(2:end);
  
endfunction
