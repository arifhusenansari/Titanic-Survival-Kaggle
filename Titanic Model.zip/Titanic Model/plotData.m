function plotData(X,y)
  
endfunction
