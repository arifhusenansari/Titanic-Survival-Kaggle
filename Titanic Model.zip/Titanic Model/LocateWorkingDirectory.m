cd E:
cd Arif
cd 'Work'
cd 'Data Science Course'
cd 'Kaggle Competition'
cd 'Titanic Survival Details'
cd 'Octave Code'

