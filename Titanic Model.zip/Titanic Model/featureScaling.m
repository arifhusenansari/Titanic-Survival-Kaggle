function f = featureScaling(data)
  minvalue=min(data,[],1) ;
  maxvalue= max(data,[],1);
  datarange=maxvalue-minvalue;
  f=(data .- minvalue)./datarange;
endfunction
