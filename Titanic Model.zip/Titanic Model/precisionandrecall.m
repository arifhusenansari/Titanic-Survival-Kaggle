function [precision, recall]= function precisionandrecall (X,y,theta)
        
endfunction
