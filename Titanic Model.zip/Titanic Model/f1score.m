function [p,r,f1] = f1score (prediction,y)
  %-- precision is the ratio of true positive and total positve predicted. 
  %-- p = tp/(tp+fp)
  
  p = sum(prediction==1 & y==1) /(sum(prediction==1 & y==1)+sum(prediction==1 * y==0))
  
  %-- recall is the ratio of true positive and actual positive in data set. 
  %-- r = tp/(tp+fn)
  r = sum(prediction==1 & y==1) /(sum(prediction==1 & y==1)+sum(prediction==0 * y==1))
  %-- f1score.
  f1 = 2*p*r /(p+r);
  
endfunction
