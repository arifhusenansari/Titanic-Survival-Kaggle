function data = convertDataToMatrix(data)
  % Convert Text data to numeric label. 
  
  X=[];
  y=[];
  % Load Output label.
  y=cell2mat(dataFromFile(2:end,2));
  dataFromFile(1:2,:)
  % Add pcclass
  X=[X cell2mat(dataFromFile(2:end,3))];
  % Add Sex
  X=[X strcmp('male',dataFromFile(2:end,5))];
  % Add Age
  strtrim(cellstr(dataFromFile(2:end,6)))
  dataFromFile(find(strcmp(dataFromFile(2:end,6),'')),6)=0
  X=[X cell2mat(dataFromFile(2:end,6))];
  % Add Sib
  X=[X dataFromFile(2:end,7)];
  % Add Parch
  X=[X dataFromFile(2:end,8)];
  % Add Fare
  X=[X dataFromFile(2:end,10)];
  
 
  
  
  
  
endfunction
